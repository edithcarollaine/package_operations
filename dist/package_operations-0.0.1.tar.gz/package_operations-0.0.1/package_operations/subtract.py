def subtract():
    a = int(input('Digite um número: '))
    b = int(input('Digite um número: '))
    result = a - b
    print(result)

